document.getElementById("checkDMARC").addEventListener("click", () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    let domain = new URL(tabs[0].url).hostname;

    chrome.runtime.sendMessage(
      { action: "checkDMARC", domain: domain },
      (response) => {
        if (chrome.runtime.lastError) {
          console.error(
            "🚨 Error handling response:",
            chrome.runtime.lastError
          );
          document.getElementById("result").innerText =
            "⚠️ Failed to get DMARC info.";
          return;
        }

        if (!response || response.hasDMARC === undefined) {
          console.error("🚨 Unexpected response:", response);
          document.getElementById("result").innerText =
            "⚠️ DMARC check failed.";
          return;
        }

        let resultText = response.hasDMARC
          ? `✅ ${domain} is DMARC Certified`
          : `❌ ${domain} is NOT DMARC Certified`;

        if (response.error) {
          resultText += `\n⚠️ ${response.error}`;
        }

        document.getElementById("result").innerText = resultText;
      }
    );
  });
});
