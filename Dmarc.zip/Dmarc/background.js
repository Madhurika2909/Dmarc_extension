chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "checkDMARC") {
    let domain = request.domain;
    let dmarcDomain = `_dmarc.${domain}`;
    let dnsAPI = `https://dns.google/resolve?name=${dmarcDomain}&type=TXT`;

    console.log(`🔎 Checking DMARC for: ${domain}`);

    fetch(dnsAPI)
      .then((response) => response.json())
      .then((data) => {
        console.log("🌐 Full API Response:", JSON.stringify(data, null, 2));

        if (!data.Answer || data.Answer.length === 0) {
          console.warn(`⚠️ No DMARC record found for ${domain}`);
          sendResponse({
            domain,
            hasDMARC: true,
          });
          return;
        }

        let records = data.Answer.map((ans) =>
          ans.data.replace(/"/g, "").trim()
        );
        console.log(`📄 Extracted Records for ${domain}:`, records);

        let hasDMARC = records.some((record) => /v=DMARC1/i.test(record));
        console.log(
          `${domain} DMARC Status: ${
            hasDMARC ? "✅ Certified" : "❌ Not Certified"
          }`
        );

        sendResponse({ domain, hasDMARC, rawRecord: records });
      })
      .catch((error) => {
        console.error(`🚨 DMARC check failed for ${domain}:`, error);
        sendResponse({
          domain,
          hasDMARC: false,
          error: "Failed to fetch DMARC.",
        });
      });

    return true; // ✅ Keeps the message port open for async response
  }
});
