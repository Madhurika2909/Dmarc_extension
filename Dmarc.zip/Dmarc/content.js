document.addEventListener("input", function (event) {
  if (event.target.tagName === "INPUT" && event.target.type === "email") {
    let email = event.target.value;
    if (email.endsWith("@gmail.com")) {
      let domain = window.location.hostname;
      chrome.runtime.sendMessage({ action: "checkDMARC", domain: domain });
    }
  }
});
